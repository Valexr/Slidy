const esbuild = require('esbuild');
const sveltePlugin = require('esbuild-svelte');
const pkg = require('./package.json');

(async () => {

	await esbuild.build({
		entryPoints: ['src/index.js'],
		outfile: pkg.main,
		format: 'cjs',
		bundle: true,
		minify: false,
		external: ['svelte', 'svelte/*'],
		plugins: [sveltePlugin()]
	});

	await esbuild.build({
		entryPoints: ['src/index.js'],
		outfile: pkg.module,
		format: "esm",
		bundle: true,
		minify: false,
		external: ['svelte', 'svelte/*'],
		plugins: [sveltePlugin({ compileOptions: { css: true } })],
	});

})()
