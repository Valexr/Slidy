export default [
		{ id: 1, src: 'https://picsum.photos/900/900.jpg?random=1' },
		{ id: 2, src: 'https://picsum.photos/1240/900.jpg?random=2' },
		{ id: 3, src: 'https://picsum.photos/1800/900.jpg?random=3' },
		{ id: 4, src: 'https://picsum.photos/1540/900.jpg?random=4' },
		{ id: 5, src: 'https://picsum.photos/540/900.jpg?random=5' },
		{ id: 6, src: 'https://picsum.photos/1140/900.jpg?random=6' },
		{ id: 7, src: 'https://picsum.photos/1640/900.jpg?random=7' },
		{ id: 8, src: 'https://picsum.photos/1840/900.jpg?random=8' },
		{ id: 9, src: 'https://picsum.photos/3000/900.jpg?random=9' },
	]