<script>
	import { onMount, afterUpdate, beforeUpdate, tick } from "svelte";
	import Slidy from "svelte-slidy";
	import Spinner from "./Spinner.svelte";
	import { getPhotos } from "./api.js";
	import { randomQ } from "./utils.js";
	import local from "./items.js";

	let name = "Slidy",
		slides = [],
		items = [],
		limit = 9,
		page = 25,
		slidyinit = false,
		index = 4;

	async function loadSlides(limit, page) {
		// loaded = intersected = intersect.entries = [];
		slidyinit = false;
		items = await getPhotos(limit, page, 1280, 800);
		// tick().then(() => (slidyinit = false))
	}

	$: if (items) slides = items;
	$: loadSlides(limit, page);

	$: console.log(items);

	const slidy = {
		// slides: slides,
		wrap: {
			id: "slidy",
			width: "100%",
			height: "50vh",
			padding: "0",
			align: "middle",
			alignmargin: 0,
		},
		slide: {
			gap: 0,
			width: "50vw",
			height: "100%",
			backimg: false,
			imgsrckey: "src",
			objectfit: "cover",
			overflow: "hidden",
		},
		controls: {
			dots: true,
			dotsnum: true,
			dotsarrow: true,
			dotspure: false,
			arrows: true,
			keys: true,
			drag: true,
			wheel: true,
		},
		options: {
			axis: "x",
			loop: true,
			duration: 350,
		},
	};
</script>

<h1>Hello <span>{name}</span>!</h1>
<div>
	<button class="slidy-ext-controls" on:click={() => limit--}> - </button>
	<button class="slidy-ext-controls" on:click={() => (page = randomQ(0, 20))}> reload </button>
	<button class="slidy-ext-controls" on:click={() => limit++}> + </button>
</div>

{#if slides.length}
	<Slidy {...slidy} {slides} bind:index bind:slidyinit>
		<span slot="loader">
			<Spinner />
		</span>
	</Slidy>
{/if}

<style lang="scss">
	:root {
		font-family: Arial, Helvetica, sans-serif;
	}
	:global(#slidy span) {
		left: 50%;
		transform: translateX(-50%);
	}
	@media screen and (min-width: 900px) {
		:global(#slidy .slidy-ul li) {
			width: 33vw;
		}
	}
	@media screen and (max-width: 425px) {
		:global(#slidy .slidy-ul li) {
			width: 100vw;
		}
	}
	h1 {
		text-align: center;
		span {
			color: red;
		}
	}
	div {
		text-align: center;
	}
</style>
