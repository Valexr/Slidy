const esbuild = require('esbuild');
const sveltePlugin = require('esbuild-svelte');
const pkg = require('./package.json');

(async () => {

	await esbuild.serve({}, {
		entryPoints: ['src/index.js'],
		outfile: pkg.module,
		format: "esm",
		bundle: true,
		minify: false,
		external: ['svelte', 'svelte/*'],
		plugins: [sveltePlugin({ compileOptions: { css: true } })],
	}).then(server => {
		// Call "stop" on the web server when you're done
		server.stop()
	})

})()
